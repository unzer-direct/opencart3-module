<?php
define('QUICKPAY_NAME', 'Unzer Direct');
define('QUICKPAY_LOGO', 'view/image/extension/payment/unzer.png');
define('QUICKPAY_LINK', 'https://www.unzer.com');

define('QUICKPAY_URL_API', 'api.unzerdirect.com');
define('QUICKPAY_URL_PAYMENT', 'payment.unzerdirect.com');
define('QUICKPAY_URL_MANAGER', 'http://insights.unzerdirect.com');