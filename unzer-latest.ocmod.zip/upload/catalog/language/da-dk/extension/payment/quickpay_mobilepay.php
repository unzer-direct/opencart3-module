<?php

$_['text_title']  = 'MobilePay';
$_['payment_fee'] = 'Betalingsgebyr';