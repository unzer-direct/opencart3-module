<?php

// Heading
$_['heading_title']         = QUICKPAY_NAME . ' ViaBill';
$_['text_quickpay_viabill'] = '<a target="_blank" href="' . QUICKPAY_LINK . '"><img style="height: 30px;" src="' . QUICKPAY_LOGO . '" alt="' . QUICKPAY_NAME . '" title="' . QUICKPAY_NAME . '" style="border: 1px solid #EEEEEE;" /></a>';