<?php

// Heading
$_['heading_title']           = 'QuickPay MobilePay';
$_['text_quickpay_mobilepay'] = '<a target="_blank" href="https://quickpay.net"><img style="height: 30px;" src="view/image/extension/payment/quickpay.svg" alt="Quickpay" title="Quickpay" style="border: 1px solid #EEEEEE;" /></a>';